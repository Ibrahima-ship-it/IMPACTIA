# Audit tricaméral — Étapes 1 à 5

Date : 27 août 2026  
Portée : pièces jointes fournies dans la conversation, sans accès aux comptes Infomaniak/WordPress et sans données réelles.

## Verdict exécutif

**Verdict binaire actuel : 0/20 — ÉTAPE 5 NON ENCORE VALIDÉE, mais écarts logiciels corrigés.**

Ce verdict ne signifie pas que le pack est inutilisable. Il applique la règle binaire demandée : Docker n’est pas disponible dans l’environnement de fabrication, donc le démarrage réel, la santé interconteneurs, l’isolation PostgreSQL, l’antivirus et la restauration ne peuvent pas être déclarés réussis. La validation passera à 20/20 uniquement lorsque chaque preuve du registre d’acceptation sera produite sur un environnement Docker/Jelastic de préproduction.

## Corrections issues du défi des trois savants

- Audit des dépendances : 62 avis de vulnérabilité ont été découverts dans les versions initialement figées.
- Correction : FastAPI, Starlette, python-multipart, PyJWT, cryptography et pypdf ont été relevés vers des versions corrigées.
- Nouvelle preuve : zéro vulnérabilité connue remontée par `pip-audit` pour le fichier d’exigences corrigé.
- Authentification : OIDC, MFA, sept rôles et contexte d’organisation sont maintenant contrôlés dans le code ; la clé partagée est limitée au mode de test hors production.
- Santé : l’API vérifie réellement PostgreSQL, Redis, le coffre objet et l’antivirus avant de se déclarer prête.
- Charge applicative : 1 000 requêtes de santé, 1 000 succès, zéro erreur, environ 984 requêtes/seconde, p95 de 83,05 ms dans l’environnement local.
- Analyse statique : zéro anomalie Bandit de sévérité moyenne ou élevée.

## Réaudit des Étapes 1–4

| Étape | Preuve reproduite | Résultat |
|---|---|---|
| 1 | Cahier des charges gelé lisible, 16 sections, ordre de livraison et critères binaires | PASS documentaire |
| 2 | Dictionnaire JSON chargé, huit axes, six contrôles machine, empreinte identique dans le moteur | PASS d’intégrité |
| 3 | 47 codes dans l’ordre M01–M12 puis L01–L35 ; 47 titres retrouvés dans la thèse canonique ; SHA-256 de la thèse concordant | PASS d’intégrité et de traçabilité |
| 4 | Les 28 tests ont été réexécutés avec succès ; ressources Étapes 2–3 identiques octet par octet | PASS noyau local |
| 5 | 10 tests applicatifs, audit de dépendances, Bandit et charge HTTP réussis | PASS logiciel ; runtime conteneurs restant |

Le PASS des Étapes 2–3 confirme la traçabilité fournie ; il ne transforme pas automatiquement chaque proposition scientifique de la thèse en vérité universelle. Les décisions demeurent humaines, situées et falsifiables.

## Socrate — maïeutique et réfutation

- Les contradictions et contre-preuves sont conservées.
- Le service échoue en mode fermé sans configuration.
- Les claims antérieurs ont été testés au lieu d’être repris comme certitudes.
- Blocage restant : scénarios réels de dissonance tri-sources et audit humain à exécuter en Étape 7.

## Aristote — logique et typologie

- L’ordre canonique des 47 fiches et les huit axes est contrôlé.
- Le double codage, le kappa et l’interdiction d’export avec désaccord ouvert sont testés dans le noyau.
- PostgreSQL prévoit une isolation par organisation et un audit non modifiable.
- Blocage restant : prouver l’isolation et l’arbitrage complet sur la composition démarrée.

## Einstein — invariance, reproductibilité et sécurité

- Les ressources canoniques ont des empreintes stables.
- L’AFC et la CHD exploratoire sont reproductibles dans les tests existants.
- L’API est non privilégiée, en lecture seule et non exposée directement.
- Blocage restant : tests indépendants AFC/CHD, charge, chiffrement applicatif, restauration et pentest.

## Écarts importants découverts

1. Le rapport de l’Étape 4 annonçait correctement 28/28 ; ce résultat a été reproduit.
2. La détection de contradictions de l’Étape 4 repose encore sur des règles limitées : elle assiste l’analyste, elle ne prouve pas une dissonance scientifique.
3. La CHD est une classification divisive K-means inspirée de Reinert, non une CHD Reinert certifiée.
4. L’API de l’Étape 4 utilisait une clé partagée. Elle a été corrigée : OIDC/MFA est le mode normal ; la clé reste uniquement disponible en mode de test non productif.
5. Le pack Étape 5 prépare les services de sécurité mais n’invente pas de preuve de démarrage absente.

## Conditions cumulatives pour 20/20

- `docker compose config` sans erreur ;
- construction d’images reproductible et analyse de vulnérabilités sans critique/élevée ouverte ;
- tous les services sains après démarrage ;
- test OIDC/MFA et chacun des sept rôles ;
- deux organisations témoins avec accès croisé refusé ;
- upload malveillant mis en quarantaine ;
- OCR et transcription privés avec consentement, corrections et purge ;
- restauration PostgreSQL + objets réussie avec empreintes conformes ;
- tests indépendants AFC/CHD et test de charge documentés ;
- aucune donnée sensible dans WordPress, journaux, variables visibles ou images ;
- zéro anomalie critique ou élevée ouverte.

## Responsabilité et procédure de clôture

Le test est exécuté par l’agent technique ou un opérateur DevOps sur un runner Docker ; le propriétaire fonctionnel n’écrit aucun code. La commande unique est `scripts/runtime_acceptance.sh`. Le script refuse les secrets factices, construit les images, démarre la composition, attend les contrôles de santé, vérifie l’isolation RLS entre deux organisations, soumet le test antivirus EICAR et produit une sauvegarde PostgreSQL avec empreinte. Seule la sortie finale `VERDICT_ETAPE_5=20/20`, accompagnée d’un code nul et des journaux, clôt l’Étape 5. La même recette est répétée sur Jelastic à l’Étape 8.
