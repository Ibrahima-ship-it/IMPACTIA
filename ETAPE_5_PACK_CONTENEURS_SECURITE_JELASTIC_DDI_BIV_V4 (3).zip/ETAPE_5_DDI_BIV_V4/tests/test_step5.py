import os
import pathlib
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

ROOT = pathlib.Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT / "app"))
from platform_api import app
from impactia_engine.auth import validate_claims


class Step5Tests(unittest.TestCase):
    def setUp(self):
        os.environ.pop("IMPACTIA_API_KEY", None)
        os.environ.pop("DATABASE_URL", None)
        os.environ["IMPACTIA_AUTH_MODE"] = "test-key"
        os.environ["IMPACTIA_ENV"] = "test"
        self.client = TestClient(app)

    def test_live(self):
        self.assertEqual(self.client.get("/health/live").status_code, 200)

    def test_ready_fails_closed_without_configuration(self):
        old_key, old_db = os.environ.pop("IMPACTIA_API_KEY", None), os.environ.pop("DATABASE_URL", None)
        try:
            response = self.client.get("/health/ready")
            self.assertEqual(response.status_code, 503)
            self.assertEqual(response.json()["status"], "blocked")
        finally:
            if old_key is not None: os.environ["IMPACTIA_API_KEY"] = old_key
            if old_db is not None: os.environ["DATABASE_URL"] = old_db

    def test_ready_with_configuration(self):
        os.environ["IMPACTIA_API_KEY"] = "test-only"
        os.environ["DATABASE_URL"] = "postgresql://invalid-but-present"
        with patch("platform_api.dependencies_ready", return_value={"postgres": True, "redis": True, "object_store": True, "antivirus": True}):
            self.assertEqual(self.client.get("/health/ready").status_code, 200)

    def test_ready_blocks_on_unavailable_dependency(self):
        os.environ["IMPACTIA_API_KEY"] = "test-only"
        os.environ["DATABASE_URL"] = "postgresql://invalid-but-present"
        with patch("platform_api.dependencies_ready", return_value={"postgres": False}):
            self.assertEqual(self.client.get("/health/ready").status_code, 503)

    def test_security_headers(self):
        headers = self.client.get("/health/live").headers
        self.assertEqual(headers["x-content-type-options"], "nosniff")
        self.assertEqual(headers["cache-control"], "no-store")

    def test_engine_rejects_missing_key(self):
        os.environ["IMPACTIA_API_KEY"] = "expected"
        response = self.client.post("/engine/v4/statistics/descriptive", json={"values": [1, 2, 3]})
        self.assertEqual(response.status_code, 401)

    def test_engine_accepts_valid_key(self):
        os.environ["IMPACTIA_API_KEY"] = "expected"
        response = self.client.post(
            "/engine/v4/statistics/descriptive",
            headers={"X-Impactia-Key": "expected"},
            json={"values": [1, 2, 3]},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["mean"], 2.0)

    def test_oidc_claims_require_mfa(self):
        with self.assertRaises(Exception):
            validate_claims({"sub":"u", "organization_id":"00000000-0000-0000-0000-000000000001", "roles":["analyst"], "acr":"weak"})

    def test_oidc_claims_require_role(self):
        with self.assertRaises(Exception):
            validate_claims({"sub":"u", "organization_id":"00000000-0000-0000-0000-000000000001", "roles":["visitor"], "acr":"urn:impactia:mfa"})

    def test_oidc_claims_accept_valid_context(self):
        claims=validate_claims({"sub":"u", "organization_id":"00000000-0000-0000-0000-000000000001", "roles":["analyst"], "acr":"urn:impactia:mfa"})
        self.assertEqual(claims["sub"],"u")


if __name__ == "__main__":
    unittest.main()
