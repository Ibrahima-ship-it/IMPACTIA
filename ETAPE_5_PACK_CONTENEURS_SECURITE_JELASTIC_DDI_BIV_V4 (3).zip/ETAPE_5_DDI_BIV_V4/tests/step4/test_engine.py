import io, json, math, tempfile, unittest, wave
from pathlib import Path
from docx import Document
from openpyxl import Workbook
from pypdf import PdfWriter

from impactia_engine.coding import suggest_codes, validate_human_code
from impactia_engine.importers import ImportFailure, import_bytes
from impactia_engine.intercoder import compare_coders
from impactia_engine.models import Segment
from impactia_engine.references import validate_references
from impactia_engine.routing import route_fiches
from impactia_engine.security import pseudonymize, safe_filename
from impactia_engine.segmentation import segment_document
from impactia_engine.statistics import descriptive, chi_square
from impactia_engine.textometry import correspondence_analysis, chd_exploratory, cooccurrences
from impactia_engine.triangulation import triangulate, detect_contradictions

class EngineTests(unittest.TestCase):
    def test_01_references(self): self.assertEqual(validate_references(),{"valid":True,"errors":[],"axes":8,"fiches":47})
    def test_02_txt(self): self.assertEqual(import_bytes("a.txt",b"Bonjour terrain","verbatim").text,"Bonjour terrain")
    def test_03_csv(self): self.assertIn("nom\tcode",import_bytes("a.csv","nom;code\nA;1".encode(),"document").text)
    def test_04_json(self): self.assertIn("root.a: 1",import_bytes("a.json",b'{"a":1}',"document").text)
    def test_05_docx(self):
        d=Document(); d.add_paragraph("Texte Word"); b=io.BytesIO(); d.save(b); self.assertIn("Texte Word",import_bytes("a.docx",b.getvalue(),"document").text)
    def test_06_xlsx(self):
        w=Workbook(); w.active.append(["A","B"]); b=io.BytesIO(); w.save(b); self.assertIn("A\tB",import_bytes("a.xlsx",b.getvalue(),"document").text)
    def test_07_pdf_empty_flag(self):
        w=PdfWriter(); w.add_blank_page(100,100); b=io.BytesIO(); w.write(b); self.assertIn("OCR_REQUIRED_OR_EMPTY_PDF",import_bytes("a.pdf",b.getvalue(),"document").warnings)
    def test_08_audio_queue(self):
        b=io.BytesIO();
        with wave.open(b,"wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000); w.writeframes(b"\x00\x00"*800)
        d=import_bytes("a.wav",b.getvalue(),"verbatim"); self.assertIn("AUDIO_TRANSCRIPTION_REQUIRED",d.warnings)
    def test_09_audio_transcript(self): self.assertEqual(import_bytes("a.mp3",b"fake","verbatim","transcrit").text,"transcrit")
    def test_10_unsupported(self):
        with self.assertRaises(ImportFailure): import_bytes("a.exe",b"x","document")
    def test_11_pseudonymize(self): self.assertIn("[EMAIL]",pseudonymize("x@y.com")[0])
    def test_12_safe_name(self): self.assertEqual(safe_filename("../../secret?.txt"),"secret_.txt")
    def test_13_segmentation(self):
        d=import_bytes("a.txt","Première phrase suffisamment longue. Deuxième phrase suffisamment longue.".encode(),"verbatim")
        self.assertEqual(len(segment_document(d)),2)
    def test_14_suggestion_not_decision(self):
        s=Segment("S","D","document",1,"Le Code minier impose un permis et une sanction.",0,49)
        r=suggest_codes(s); self.assertEqual(r.decision_status,"A_ARBITRER"); self.assertTrue(r.human_validation_required)
    def test_15_human_code(self): self.assertTrue(validate_human_code("S","I",None,"Justification analytique suffisamment précise.")["human_validated"])
    def test_16_reclass_proof(self):
        with self.assertRaises(ValueError): validate_human_code("S","I",None,"Justification analytique suffisamment précise.","RECLASSEMENT_DOCUMENTE")
    def test_17_kappa_perfect(self): self.assertEqual(compare_coders({"1":"I"},{"1":"I"})["cohen_kappa"],1.0)
    def test_18_arbitration_blocks(self): self.assertFalse(compare_coders({"1":"I"},{"1":"II"})["report_export_allowed"])
    def test_19_arbitration_unlocks(self): self.assertTrue(compare_coders({"1":"I"},{"1":"II"},{"1":"I"})["report_export_allowed"])
    def test_20_descriptive(self): self.assertEqual(descriptive([1,2,3])["mean"],2.0)
    def test_21_chi(self): self.assertGreaterEqual(chi_square([[10,2],[3,9]])["cramers_v"],0)
    def test_22_afc(self): self.assertEqual(len(correspondence_analysis([[10,2],[3,9]])["row_coordinates"]),2)
    def test_23_chd_reproducible(self):
        t=["loi permis sanction","décret norme permis","confiance dialogue consensus","partenariat dialogue confiance"]
        self.assertEqual(chd_exploratory(t)["assignments"],chd_exploratory(t)["assignments"])
    def test_24_cooccurrence(self): self.assertTrue(cooccurrences(["loi permis","loi norme"]))
    def test_25_triangulation(self): self.assertEqual(triangulate([{"axis":"I","source_type":"verbatim","segment_id":"1"}])["axes"][0]["status"],"PARTIAL")
    def test_26_contradiction(self): self.assertTrue(detect_contradictions({"document":"100% conforme","verbatim":"pollution et jamais consulté"}))
    def test_27_route_count(self): self.assertEqual(len(route_fiches(limit=47)),47)
    def test_28_route_ddi2(self): self.assertTrue(route_fiches(interface="DDI-2",limit=10))

if __name__=="__main__": unittest.main()
