#!/bin/sh
set -eu

: "${POSTGRES_APP_USER:?POSTGRES_APP_USER requis}"
: "${POSTGRES_APP_PASSWORD:?POSTGRES_APP_PASSWORD requis}"

psql --set=ON_ERROR_STOP=1 \
  --username "$POSTGRES_USER" \
  --dbname "$POSTGRES_DB" \
  --set=app_user="$POSTGRES_APP_USER" \
  --set=app_password="$POSTGRES_APP_PASSWORD" <<'SQL'
CREATE ROLE :"app_user"
  LOGIN PASSWORD :'app_password'
  NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
SQL

