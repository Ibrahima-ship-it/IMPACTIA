# IMPACTIA DDI-BIV Enterprise V4 — Étape 5

Pack de préproduction conteneurisé, construit à partir du moteur reproductible de l’Étape 4 et des référentiels gelés des Étapes 2–3.

## Ce que ce pack garantit

- aucune donnée confidentielle réelle ni aucun secret inclus ;
- API en mode fermé en l’absence de configuration ;
- 47 fiches et dictionnaire canonique embarqués sans modification ;
- réseau de services interne, conteneur API non privilégié et lecture seule ;
- PostgreSQL avec isolation RLS et journal append-only ;
- stockage objet séparé, Redis éphémère, quarantaine antivirus ;
- terminaison TLS et limites de requêtes prévues à la passerelle ;
- OCR/transcription laissés bloqués tant que leur chaîne privée et leur consentement ne sont pas homologués.

## Limite bloquante de cette livraison

L’environnement de fabrication utilisé pour produire ce pack ne fournit pas Docker. Les tests Python et les contrôles statiques sont exécutés, mais le démarrage réel de la composition doit être reproduit sur une machine Docker/Jelastic avant validation binaire de l’Étape 5. Le fichier `RAPPORT_AUDIT_ETAPE_5.md` conserve explicitement cette réserve.

## Démarrage autorisé uniquement avec données synthétiques

1. Copier `.env.example` vers `.env` et remplacer toutes les valeurs `CHANGE_*` hors dépôt.
2. Installer des certificats de préproduction dans `certs/`.
3. Exécuter `python scripts/preflight.py`.
4. Exécuter `docker compose config`, puis `docker compose build --pull`.
5. Exécuter `scripts/runtime_acceptance.sh`. Ce script construit et démarre les services, attend leur santé, teste l’isolation entre deux organisations, le fichier antivirus EICAR et une sauvegarde PostgreSQL.
6. Le seul résultat autorisant la clôture est `VERDICT_ETAPE_5=20/20` avec un code de sortie nul.
7. Conserver la sortie complète comme preuve d’audit avant toute donnée réelle.

Ce pack n’active ni Jelastic, ni WordPress, ni l’IA externe.

Dans GitHub Actions, `runtime_acceptance.sh` détecte automatiquement le runner, génère des secrets et certificats éphémères, puis remplace tout `.env` factice. Aucun secret réel ne doit être envoyé dans le ZIP ou enregistré dans le dépôt.
