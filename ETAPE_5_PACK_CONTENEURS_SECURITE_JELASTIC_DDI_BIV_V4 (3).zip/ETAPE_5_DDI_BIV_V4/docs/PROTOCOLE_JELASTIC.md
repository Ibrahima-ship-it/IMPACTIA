# Protocole Jelastic — sans achat ni activation

Le contrôle Étape 5 s’exécute d’abord sur un runner Docker neutre au moyen de `scripts/runtime_acceptance.sh`. L’Étape 8 répète la même recette sur Jelastic après autorisation. Cette séparation évite de rendre l’Étape 5 dépendante d’un achat Jelastic prématuré.

## Topologie minimale

- passerelle Nginx/WAF exposée ;
- API et worker sur réseau privé ;
- PostgreSQL, Redis, stockage objet et antivirus sans port public ;
- identité OIDC/MFA externe ou service d’identité privé homologué ;
- secrets injectés par le gestionnaire de secrets de la plateforme.

## Portes obligatoires avant activation

1. Étapes 1–7 approuvées et versionnées.
2. Sauvegarde complète du WordPress actuel vérifiée par restauration hors production.
3. DNS `app.impactia-group.com` préparé mais non basculé.
4. Certificat TLS de préproduction valide.
5. Aucune donnée de thèse confidentielle ni donnée d’entreprise dans les essais.
6. Tests négatifs d’accès entre deux organisations.
7. Test antivirus avec fichier EICAR dans un environnement isolé.
8. Restauration PostgreSQL et stockage objet chronométrée.
9. Revue des journaux sans contenu sensible.
10. Approbation formelle de l’essai de 14 jours.

## Interdictions

- ne pas placer de clé dans Divi, JavaScript, shortcode ou URL ;
- ne pas stocker les sources dans la médiathèque WordPress ;
- ne pas exposer PostgreSQL, Redis, MinIO ou ClamAV à Internet ;
- ne pas activer Whisper ou un LLM externe par défaut ;
- ne pas déclarer la CHD comme copie de Sphinx ou IRaMuTeQ.
