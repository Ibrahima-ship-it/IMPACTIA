# Runbook sécurité, sauvegarde et restauration

## Sauvegardes

- sauvegarde PostgreSQL chiffrée quotidienne ;
- versionnement et réplication du coffre objet ;
- manifest SHA-256 signé séparément ;
- clés hors sauvegarde, avec procédure de récupération sous double contrôle ;
- rétention définie par organisation et obligation légale.

## Test de restauration

1. Restaurer dans un environnement isolé sans accès public.
2. Vérifier les empreintes des objets.
3. Rejouer les migrations de schéma en lecture seule.
4. Vérifier les comptes, projets, codages A/B, arbitrages et événements d’audit.
5. Confirmer qu’aucune organisation ne peut lire celle du jeu témoin.
6. Documenter RPO, RTO, écarts et approbateur.

## Incident

- révoquer les jetons et clés concernés ;
- isoler le service sans supprimer les journaux ;
- préserver les preuves ;
- qualifier les obligations de notification ;
- restaurer depuis une version vérifiée ;
- enregistrer la décision et la contre-preuve.

