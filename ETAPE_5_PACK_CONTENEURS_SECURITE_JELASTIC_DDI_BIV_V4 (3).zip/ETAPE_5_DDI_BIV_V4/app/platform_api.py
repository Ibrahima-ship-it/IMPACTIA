from __future__ import annotations

import os
import socket
from urllib.parse import urlparse
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from impactia_engine.api import app as engine_app
from impactia_engine.references import validate_references

app = FastAPI(
    title="IMPACTIA DDI-BIV Enterprise V4",
    version="5.0.0-preproduction",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)


def _tcp_probe(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=1.0):
            return True
    except OSError:
        return False


def dependencies_ready() -> dict[str, bool]:
    database = urlparse(os.getenv("DATABASE_URL", ""))
    redis = urlparse(os.getenv("REDIS_URL", ""))
    s3 = urlparse(os.getenv("S3_ENDPOINT", ""))
    return {
        "postgres": bool(database.hostname) and _tcp_probe(database.hostname, database.port or 5432),
        "redis": bool(redis.hostname) and _tcp_probe(redis.hostname, redis.port or 6379),
        "object_store": bool(s3.hostname) and _tcp_probe(s3.hostname, s3.port or 9000),
        "antivirus": _tcp_probe(os.getenv("CLAMAV_HOST", ""), int(os.getenv("CLAMAV_PORT", "3310"))),
    }


@app.middleware("http")
async def security_headers(request: Request, call_next):
    request_id = request.headers.get("x-request-id", "not-provided")[:128]
    response = await call_next(request)
    response.headers.update({
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
        "Cache-Control": "no-store",
        "X-Request-ID": request_id,
    })
    return response


@app.get("/health/live", include_in_schema=False)
def live():
    return {"status": "alive"}


@app.get("/health/ready", include_in_schema=False)
def ready():
    checks = validate_references()
    auth_mode = os.getenv("IMPACTIA_AUTH_MODE", "oidc")
    auth_configured = (
        bool(os.getenv("OIDC_ISSUER")) and bool(os.getenv("OIDC_AUDIENCE"))
        if auth_mode == "oidc"
        else bool(os.getenv("IMPACTIA_API_KEY")) and os.getenv("IMPACTIA_ENV") != "production"
    )
    configured = auth_configured and bool(os.getenv("DATABASE_URL"))
    dependencies = dependencies_ready() if configured else {}
    ok = checks.get("valid") is True and configured and all(dependencies.values())
    return JSONResponse(
        status_code=200 if ok else 503,
        content={"status": "ready" if ok else "blocked", "references": checks, "configuration_present": configured, "dependencies": dependencies},
    )


app.mount("/engine", engine_app)
