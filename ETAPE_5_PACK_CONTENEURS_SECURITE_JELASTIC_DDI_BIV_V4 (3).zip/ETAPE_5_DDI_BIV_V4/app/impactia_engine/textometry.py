from __future__ import annotations
import numpy as np
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import CountVectorizer

def document_term_matrix(texts:list[str],max_features:int=500,min_df:int=1):
    if len(texts)<2: raise ValueError("AT_LEAST_TWO_TEXTS_REQUIRED")
    vec=CountVectorizer(max_features=max_features,min_df=min_df,lowercase=True,token_pattern=r"(?u)\b[^\W\d_]{2,}\b")
    x=vec.fit_transform(texts).toarray().astype(float)
    if x.shape[1]<2: raise ValueError("VOCABULARY_TOO_SMALL")
    return x,vec.get_feature_names_out().tolist()

def correspondence_analysis(table:list[list[float]],dimensions:int=2)->dict:
    n=np.asarray(table,dtype=float)
    if n.ndim!=2 or n.sum()<=0 or np.any(n<0): raise ValueError("TABLE_INVALID")
    keep_r=n.sum(axis=1)>0; keep_c=n.sum(axis=0)>0; n=n[keep_r][:,keep_c]
    p=n/n.sum(); r=p.sum(axis=1); c=p.sum(axis=0)
    s=(p-np.outer(r,c))/np.sqrt(np.outer(r,c))
    u,sing,vt=np.linalg.svd(s,full_matrices=False); dims=min(dimensions,len(sing))
    row=(u[:,:dims]*sing[:dims])/np.sqrt(r)[:,None]; col=(vt[:dims,:].T*sing[:dims])/np.sqrt(c)[:,None]
    eig=sing**2; inertia=(eig/eig.sum()).tolist() if eig.sum() else [0.0]*len(eig)
    return {"row_coordinates":row.tolist(),"column_coordinates":col.tolist(),"singular_values":sing[:dims].tolist(),"explained_inertia":inertia[:dims],"method":"CORRESPONDENCE_ANALYSIS_SVD","exploratory":True}

def chd_exploratory(texts:list[str],max_classes:int=4,random_state:int=42)->dict:
    x,terms=document_term_matrix(texts,max_features=500); n=len(texts); target=max(2,min(max_classes,n))
    leaves=[list(range(n))]
    while len(leaves)<target:
        idx=max(range(len(leaves)),key=lambda i:len(leaves[i])); group=leaves.pop(idx)
        if len(group)<2: leaves.append(group); break
        km=KMeans(n_clusters=2,random_state=random_state,n_init=20).fit(x[group])
        a=[group[i] for i,v in enumerate(km.labels_) if v==0]; b=[group[i] for i,v in enumerate(km.labels_) if v==1]
        if not a or not b: leaves.append(group); break
        leaves.extend([a,b])
    assignments=[-1]*n; classes=[]
    global_freq=x.sum(axis=0)+1e-9
    for ci,group in enumerate(leaves,1):
        for i in group: assignments[i]=ci
        freq=x[group].sum(axis=0); ratio=(freq/max(1,len(group)))/(global_freq/max(1,n))
        top=np.argsort(-ratio)[:10]
        classes.append({"class_id":ci,"document_indices":group,"size":len(group),"characteristic_terms":[{"term":terms[j],"specificity":float(ratio[j]),"count":int(freq[j])} for j in top if freq[j]>0]})
    return {"assignments":assignments,"classes":classes,"method":"DIVISIVE_KMEANS_REINERT_INSPIRED","random_state":random_state,"exploratory":True,"not_proprietary_equivalence":True}

def cooccurrences(texts:list[str],top_n:int=30)->list[dict]:
    x,terms=document_term_matrix(texts,max_features=300); binary=(x>0).astype(int); co=binary.T@binary; np.fill_diagonal(co,0)
    pairs=[]
    for i in range(len(terms)):
        for j in range(i+1,len(terms)):
            if co[i,j]: pairs.append({"term_a":terms[i],"term_b":terms[j],"documents":int(co[i,j])})
    return sorted(pairs,key=lambda z:(-z["documents"],z["term_a"],z["term_b"]))[:top_n]
