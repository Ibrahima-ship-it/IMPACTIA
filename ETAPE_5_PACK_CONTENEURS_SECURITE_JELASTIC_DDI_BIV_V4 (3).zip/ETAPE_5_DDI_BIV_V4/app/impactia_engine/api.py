"""Adaptateur FastAPI. Les dépendances web seront installées dans les conteneurs de l’Étape 5."""
from __future__ import annotations
import hmac, os
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from .intercoder import compare_coders
from .references import validate_references
from .routing import route_fiches
from .statistics import descriptive, chi_square
from .textometry import correspondence_analysis, chd_exploratory
from .auth import verify_oidc

app=FastAPI(title="IMPACTIA DDI-BIV Analytics Engine",version="4.0.0",docs_url=None,redoc_url=None)
class IntercoderPayload(BaseModel):
    coder_a:dict[str,str]; coder_b:dict[str,str]; arbitrations:dict[str,str]=Field(default_factory=dict)
class TextPayload(BaseModel): texts:list[str]=Field(min_length=2,max_length=5000)
class AFCBody(BaseModel): table:list[list[float]]
class StatsBody(BaseModel): values:list[float]
class ChiBody(BaseModel): table:list[list[float]]
class RouteBody(BaseModel): interface:str|None=None; configuration:str|None=None; query:str|None=None; limit:int=Field(default=10,ge=1,le=47)

def auth(x_impactia_key:str="", authorization:str=""):
    mode=os.getenv("IMPACTIA_AUTH_MODE","oidc")
    if mode == "test-key" and os.getenv("IMPACTIA_ENV","preproduction") != "production":
        expected=os.getenv("IMPACTIA_API_KEY","")
        if expected and hmac.compare_digest(x_impactia_key,expected): return {"mode":"test-key"}
        raise HTTPException(401,"Accès refusé")
    return verify_oidc(authorization)

@app.get("/health")
def health(): return {"status":"ok","reference":validate_references()}
@app.post("/v4/intercoder",dependencies=[])
def intercoder(p:IntercoderPayload,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")):
    auth(key,authorization); return compare_coders(p.coder_a,p.coder_b,p.arbitrations)
@app.post("/v4/chd")
def chd(p:TextPayload,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")): auth(key,authorization); return chd_exploratory(p.texts)
@app.post("/v4/afc")
def afc(p:AFCBody,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")): auth(key,authorization); return correspondence_analysis(p.table)
@app.post("/v4/statistics/descriptive")
def stats(p:StatsBody,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")): auth(key,authorization); return descriptive(p.values)
@app.post("/v4/statistics/chi-square")
def chi(p:ChiBody,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")): auth(key,authorization); return chi_square(p.table)
@app.post("/v4/fiches/route")
def route(p:RouteBody,key=Header(default="",alias="X-Impactia-Key"),authorization=Header(default="",alias="Authorization")): auth(key,authorization); return route_fiches(p.interface,p.configuration,p.query,p.limit)
