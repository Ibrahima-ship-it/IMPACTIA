from __future__ import annotations

import os
from functools import lru_cache
from uuid import UUID

import jwt
from fastapi import HTTPException
from jwt import PyJWKClient

ALLOWED_ROLES = {
    "platform_admin", "organization_admin", "analyst", "coder",
    "arbitrator", "reviewer", "approver",
}


def validate_claims(claims: dict) -> dict:
    mfa_claim = os.getenv("OIDC_REQUIRED_MFA_CLAIM", "acr")
    mfa_value = os.getenv("OIDC_REQUIRED_MFA_VALUE", "urn:impactia:mfa")
    if claims.get(mfa_claim) != mfa_value:
        raise HTTPException(403, "MFA obligatoire")
    roles = set(claims.get("roles", []))
    if not roles.intersection(ALLOWED_ROLES):
        raise HTTPException(403, "Rôle DDI-BIV absent")
    try:
        UUID(str(claims["organization_id"]))
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(403, "Organisation absente ou invalide") from exc
    if not claims.get("sub"):
        raise HTTPException(403, "Sujet absent")
    return claims


@lru_cache(maxsize=1)
def _jwk_client() -> PyJWKClient:
    issuer = os.environ["OIDC_ISSUER"].rstrip("/")
    return PyJWKClient(f"{issuer}/protocol/openid-connect/certs", cache_keys=True, lifespan=300)


def verify_oidc(authorization: str) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Jeton Bearer requis")
    token = authorization[7:]
    try:
        key = _jwk_client().get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256", "ES256"],
            audience=os.environ["OIDC_AUDIENCE"],
            issuer=os.environ["OIDC_ISSUER"].rstrip("/"),
            options={"require": ["exp", "iat", "iss", "aud", "sub"]},
        )
    except (KeyError, jwt.PyJWTError) as exc:
        raise HTTPException(401, "Jeton invalide") from exc
    return validate_claims(claims)

