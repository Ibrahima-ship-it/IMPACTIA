from __future__ import annotations
from .coding import suggest_codes
from .segmentation import segment_document
from .textometry import chd_exploratory, correspondence_analysis, cooccurrences, document_term_matrix
from .triangulation import detect_contradictions

def analyze_documents(documents:list,run_textometry:bool=True)->dict:
    segments=[s for d in documents for s in segment_document(d)]
    suggestions=[suggest_codes(s).to_dict() for s in segments]
    result={"documents":[d.to_dict() for d in documents],"segments":[s.to_dict() for s in segments],"coding_suggestions":suggestions,"human_validation_required":True,"report_export_allowed":False,"contradictions":detect_contradictions({d.source_type:d.text for d in documents})}
    texts=[s.text for s in segments]
    if run_textometry and len(texts)>=2:
        x,terms=document_term_matrix(texts)
        result["textometry"]={"terms":terms,"cooccurrences":cooccurrences(texts),"afc":correspondence_analysis(x.tolist()),"chd":chd_exploratory(texts,min(4,len(texts)))}
    return result
