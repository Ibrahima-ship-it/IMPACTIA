from __future__ import annotations
from collections import defaultdict

def triangulate(coded_segments:list[dict])->dict:
    by_axis=defaultdict(lambda:defaultdict(int)); evidence=defaultdict(list)
    for x in coded_segments:
        axis=x["axis"]; src=x["source_type"]; by_axis[axis][src]+=1; evidence[axis].append(x.get("segment_id"))
    rows=[]
    expected={"verbatim","document","observation"}
    for axis in sorted(by_axis):
        present={k for k,v in by_axis[axis].items() if v>0}; missing=sorted(expected-present)
        rows.append({"axis":axis,"counts":dict(by_axis[axis]),"sources_present":sorted(present),"missing_sources":missing,"status":"TRIANGULATED" if not missing else "PARTIAL","evidence_ids":evidence[axis]})
    return {"axes":rows,"policy":"DIVERGENCES_PRESERVED_HUMAN_REVIEW","automatic_validation":False}

def detect_contradictions(source_texts:dict[str,str])->list[dict]:
    positive=("conforme","respecté","validé","100%","aucun incident","dialogue régulier")
    negative=("non conforme","jamais","pollution","conflit","aucun responsable","non respecté","refus")
    signals={s:{"positive":[w for w in positive if w in t.lower()],"negative":[w for w in negative if w in t.lower()]} for s,t in source_texts.items()}
    out=[]; sources=list(signals)
    for i,a in enumerate(sources):
        for b in sources[i+1:]:
            if (signals[a]["positive"] and signals[b]["negative"]) or (signals[b]["positive"] and signals[a]["negative"]):
                out.append({"source_a":a,"source_b":b,"signals_a":signals[a],"signals_b":signals[b],"status":"HUMAN_REVIEW_REQUIRED"})
    return out
