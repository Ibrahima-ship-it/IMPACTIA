from __future__ import annotations
from collections import Counter

def compare_coders(codes_a:dict[str,str],codes_b:dict[str,str],arbitrations:dict[str,str]|None=None)->dict:
    ids=sorted(set(codes_a)&set(codes_b)); arbitrations=arbitrations or {}
    labels=sorted(set(codes_a[i] for i in ids)|set(codes_b[i] for i in ids))
    matrix={a:{b:0 for b in labels} for a in labels}
    agree=0; disagreements=[]
    for i in ids:
        a,b=codes_a[i],codes_b[i]; matrix[a][b]+=1
        if a==b: agree+=1
        else: disagreements.append({"segment_id":i,"coder_a":a,"coder_b":b,"arbitrated_code":arbitrations.get(i),"resolved":i in arbitrations})
    n=len(ids); po=agree/n if n else 0.0
    ca=Counter(codes_a[i] for i in ids); cb=Counter(codes_b[i] for i in ids)
    pe=sum((ca[l]/n)*(cb[l]/n) for l in labels) if n else 0.0
    kappa=(po-pe)/(1-pe) if n and pe<1 else (1.0 if n and po==1 else 0.0)
    unresolved=sum(not d["resolved"] for d in disagreements)
    return {"n":n,"labels":labels,"observed_agreement":round(po,6),"expected_agreement":round(pe,6),"cohen_kappa":round(kappa,6),"confusion_matrix":matrix,"disagreements":disagreements,"unresolved":unresolved,"report_export_allowed":unresolved==0}
