from __future__ import annotations
import re

DIRECT_PATTERNS = [
    (re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b"), "[EMAIL]"),
    (re.compile(r"(?<!\w)(?:\+?224[ .-]?)?(?:6\d{2})(?:[ .-]?\d{2}){3}(?!\w)"), "[TELEPHONE]"),
]

def pseudonymize(text: str, replacements: dict[str,str] | None = None) -> tuple[str,list[str]]:
    out=text; applied=[]
    for pattern, token in DIRECT_PATTERNS:
        out,n=pattern.subn(token,out)
        if n: applied.append(token)
    for raw, token in (replacements or {}).items():
        if raw:
            out,n=re.subn(re.escape(raw),token,out,flags=re.IGNORECASE)
            if n: applied.append(token)
    return out, sorted(set(applied))

def safe_filename(name: str) -> str:
    clean=re.sub(r"[^A-Za-z0-9._-]+","_",name).strip("._")
    return clean[:180] or "document"
