from __future__ import annotations
import re
from .references import fiche_registry

def route_fiches(interface:str|None=None,configuration:str|None=None,query:str|None=None,limit:int=10)->list[dict]:
    interface=(interface or "").upper(); configuration=(configuration or "").upper(); q=(query or "").lower(); out=[]
    for f in fiche_registry()["fiches"]:
        fields=f["layer_b"]["fields"]; routing=fields.get("Routage","")
        hay=(f["title_canonical"]+" "+f["layer_a"]["text"]+" "+routing).lower(); score=0; reasons=[]
        if interface and interface in routing.upper(): score+=4; reasons.append(interface)
        if configuration and configuration in routing.upper(): score+=3; reasons.append(configuration)
        if q:
            hits=[w for w in re.findall(r"\w{3,}",q) if w in hay]; score+=len(set(hits)); reasons+=sorted(set(hits))
        if score or (not interface and not configuration and not q): out.append({"code":f["code"],"title":f["title_canonical"],"score":score,"reasons":reasons,"routing":routing,"control_status":f["control_status"]})
    return sorted(out,key=lambda x:(-x["score"],x["code"]))[:limit]
