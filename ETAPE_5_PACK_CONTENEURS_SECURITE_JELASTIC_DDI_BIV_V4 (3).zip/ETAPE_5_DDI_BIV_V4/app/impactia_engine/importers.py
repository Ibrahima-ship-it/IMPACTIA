from __future__ import annotations
import csv, hashlib, io, json, mimetypes, wave
from pathlib import Path
from typing import Callable
from docx import Document
from openpyxl import load_workbook
from pypdf import PdfReader
from .models import ImportedDocument
from .security import safe_filename

MAX_FILE_BYTES = 50 * 1024 * 1024
TEXT_EXT={".txt",".md"}; AUDIO_EXT={".wav",".mp3",".m4a",".ogg",".flac",".aac"}

class ImportFailure(ValueError): pass

def _decode(data: bytes) -> str:
    for enc in ("utf-8-sig","utf-8","cp1252","latin-1"):
        try: return data.decode(enc)
        except UnicodeDecodeError: pass
    raise ImportFailure("ENCODING_UNSUPPORTED")

def _text(data:bytes, _:str)->tuple[str,dict,list[str]]: return _decode(data),{},[]
def _csv(data:bytes, _:str)->tuple[str,dict,list[str]]:
    txt=_decode(data); sample=txt[:4096]
    try: dialect=csv.Sniffer().sniff(sample,delimiters=",;\t|")
    except csv.Error: dialect=csv.excel
    rows=list(csv.reader(io.StringIO(txt),dialect)); return "\n".join("\t".join(c.strip() for c in row) for row in rows),{"rows":len(rows)},[]
def _json(data:bytes, _:str)->tuple[str,dict,list[str]]:
    obj=json.loads(_decode(data)); lines=[]
    def walk(x,path="root"):
        if isinstance(x,dict):
            for k,v in x.items(): walk(v,f"{path}.{k}")
        elif isinstance(x,list):
            for i,v in enumerate(x): walk(v,f"{path}[{i}]")
        else: lines.append(f"{path}: {x}")
    walk(obj); return "\n".join(lines),{"root_type":type(obj).__name__},[]
def _docx(data:bytes, _:str)->tuple[str,dict,list[str]]:
    d=Document(io.BytesIO(data)); parts=[p.text.strip() for p in d.paragraphs if p.text.strip()]
    for ti,t in enumerate(d.tables,1):
        for row in t.rows: parts.append("\t".join(c.text.strip() for c in row.cells))
    return "\n".join(parts),{"paragraphs":len(d.paragraphs),"tables":len(d.tables)},[]
def _xlsx(data:bytes, _:str)->tuple[str,dict,list[str]]:
    wb=load_workbook(io.BytesIO(data),read_only=True,data_only=True); parts=[]; rows=0
    for ws in wb.worksheets:
        parts.append(f"[FEUILLE: {ws.title}]")
        for row in ws.iter_rows(values_only=True):
            vals=["" if v is None else str(v) for v in row]
            if any(vals): parts.append("\t".join(vals)); rows+=1
    return "\n".join(parts),{"sheets":wb.sheetnames,"rows":rows},[]
def _pdf(data:bytes, _:str)->tuple[str,dict,list[str]]:
    reader=PdfReader(io.BytesIO(data)); parts=[]
    for i,p in enumerate(reader.pages,1): parts.append(f"[PAGE {i}]\n{p.extract_text() or ''}")
    txt="\n".join(parts); warnings=[]
    if len(txt.replace("[PAGE","").strip())<20: warnings.append("OCR_REQUIRED_OR_EMPTY_PDF")
    return txt,{"pages":len(reader.pages)},warnings
def _audio(data:bytes, filename:str, transcript: str | None=None)->tuple[str,dict,list[str]]:
    ext=Path(filename).suffix.lower(); meta={"transcription_status":"PROVIDED" if transcript else "REQUIRED"}
    if ext==".wav":
        try:
            with wave.open(io.BytesIO(data),"rb") as w: meta["duration_seconds"]=round(w.getnframes()/max(1,w.getframerate()),3)
        except wave.Error: pass
    if transcript: return transcript,meta,[]
    return "",meta,["AUDIO_TRANSCRIPTION_REQUIRED"]

def transcribe_with_whisper(path: str, model_size: str="small", language: str="fr") -> str:
    try: from faster_whisper import WhisperModel
    except ImportError as e: raise ImportFailure("OPTIONAL_WHISPER_NOT_INSTALLED") from e
    model=WhisperModel(model_size,device="cpu",compute_type="int8")
    segments,_=model.transcribe(path,language=language,vad_filter=True)
    return " ".join(s.text.strip() for s in segments)

def import_bytes(filename:str,data:bytes,source_type:str,transcript:str|None=None)->ImportedDocument:
    if not data: raise ImportFailure("EMPTY_FILE")
    if len(data)>MAX_FILE_BYTES: raise ImportFailure("FILE_TOO_LARGE")
    ext=Path(filename).suffix.lower(); media=mimetypes.guess_type(filename)[0] or "application/octet-stream"
    if ext in TEXT_EXT: text,meta,warn=_text(data,filename)
    elif ext==".csv" or ext==".tsv": text,meta,warn=_csv(data,filename)
    elif ext==".json": text,meta,warn=_json(data,filename)
    elif ext==".docx": text,meta,warn=_docx(data,filename)
    elif ext==".xlsx": text,meta,warn=_xlsx(data,filename)
    elif ext==".pdf": text,meta,warn=_pdf(data,filename)
    elif ext in AUDIO_EXT: text,meta,warn=_audio(data,filename,transcript)
    else: raise ImportFailure(f"FORMAT_UNSUPPORTED:{ext or 'none'}")
    digest=hashlib.sha256(data).hexdigest(); doc_id="DOC-"+digest[:16].upper()
    return ImportedDocument(doc_id,safe_filename(filename),media,source_type,text,digest,warn,meta)
