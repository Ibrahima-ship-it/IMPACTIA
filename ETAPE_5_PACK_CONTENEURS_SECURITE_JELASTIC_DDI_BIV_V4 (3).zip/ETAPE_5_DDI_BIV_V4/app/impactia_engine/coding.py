from __future__ import annotations
import math, re, unicodedata
from .models import Segment, CodingSuggestion
from .references import coding_dictionary

def _norm(s:str)->str:
    s=unicodedata.normalize("NFKD",s.lower()); return "".join(c for c in s if not unicodedata.combining(c))
def _tokens(s:str)->set[str]: return set(re.findall(r"[a-z0-9]+",_norm(s)))

def suggest_codes(segment:Segment,limit:int=3)->CodingSuggestion:
    text=_norm(segment.text); results=[]
    for axis in coding_dictionary()["axes"]:
        hits=[]
        for marker in axis.get("markers",[]):
            if _norm(marker) in text: hits.append(marker)
        score=len(hits)/max(1,len(axis.get("markers",[])))
        if hits: results.append({"axis":axis["id"],"name":axis["name"],"score":round(score,4),"matched_markers":hits,"priority":axis.get("priority"),"warning":"INDICE_NON_DECISIONNEL"})
    results.sort(key=lambda x:(-x["score"],x.get("priority") or 99,x["axis"]))
    return CodingSuggestion(segment.segment_id,results[:limit])

def validate_human_code(segment_id:str,axis:str,category:str|None,justification:str,status:str="ATTRIBUTION_STABILISEE",previous_code:str|None=None,version_evidence:str|None=None)->dict:
    valid_axes={a["id"] for a in coding_dictionary()["axes"]}
    if axis not in valid_axes: raise ValueError("AXIS_INVALID")
    if len(justification.strip())<20: raise ValueError("JUSTIFICATION_TOO_SHORT")
    if status=="RECLASSEMENT_DOCUMENTE" and (not previous_code or not version_evidence): raise ValueError("RECLASSIFICATION_EVIDENCE_REQUIRED")
    return {"segment_id":segment_id,"axis":axis,"category":category,"justification":justification.strip(),"status":status,"previous_code":previous_code,"version_evidence":version_evidence,"human_validated":True}
