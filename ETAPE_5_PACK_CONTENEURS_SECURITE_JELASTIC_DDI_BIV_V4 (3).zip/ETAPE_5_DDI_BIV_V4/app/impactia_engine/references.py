from __future__ import annotations
import json
from functools import lru_cache
from pathlib import Path

RESOURCE_DIR = Path(__file__).with_name("resources")

@lru_cache
def coding_dictionary() -> dict:
    return json.loads((RESOURCE_DIR / "coding_dictionary_v4.json").read_text(encoding="utf-8"))

@lru_cache
def fiche_registry() -> dict:
    return json.loads((RESOURCE_DIR / "fiches_47_v4.json").read_text(encoding="utf-8"))

def validate_references() -> dict:
    coding = coding_dictionary(); fiches = fiche_registry()
    errors=[]
    if len(coding.get("axes", [])) != 8: errors.append("CODING_AXES_NOT_8")
    if len(fiches.get("fiches", [])) != 47: errors.append("FICHES_NOT_47")
    expected=[f"M{i:02d}" for i in range(1,13)]+[f"L{i:02d}" for i in range(1,36)]
    actual=[f.get("code") for f in fiches.get("fiches", [])]
    if actual != expected: errors.append("FICHE_ORDER_INVALID")
    if any(f.get("control_status") != "CONFORME" for f in fiches.get("fiches", [])): errors.append("FICHE_NONCONFORMITY")
    return {"valid":not errors,"errors":errors,"axes":len(coding.get("axes",[])),"fiches":len(actual)}
