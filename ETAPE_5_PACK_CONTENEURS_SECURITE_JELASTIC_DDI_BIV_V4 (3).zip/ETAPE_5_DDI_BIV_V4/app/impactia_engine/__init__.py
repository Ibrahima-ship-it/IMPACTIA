"""IMPACTIA DDI-BIV engine, canonical Step 4."""
__version__ = "4.0.0"
