from __future__ import annotations
import re
from .models import ImportedDocument, Segment
from .security import pseudonymize

BOUNDARY=re.compile(r"(?<=[.!?])\s+(?=[A-ZÀ-ÖØ-Þ0-9])|\n{2,}")

def segment_document(doc:ImportedDocument,replacements:dict[str,str]|None=None,min_chars:int=20,max_chars:int=1200)->list[Segment]:
    text,tokens=pseudonymize(doc.text,replacements)
    chunks=[]
    for part in BOUNDARY.split(text):
        part=part.strip()
        if not part: continue
        while len(part)>max_chars:
            cut=part.rfind(" ",0,max_chars)
            if cut<min_chars: cut=max_chars
            chunks.append(part[:cut].strip()); part=part[cut:].strip()
        if part: chunks.append(part)
    merged=[]
    for c in chunks:
        if merged and len(c)<min_chars: merged[-1]+=" "+c
        else: merged.append(c)
    out=[]; cursor=0
    for i,c in enumerate(merged,1):
        pos=text.find(c,cursor); pos=max(cursor,pos); end=pos+len(c); cursor=end
        out.append(Segment(f"{doc.document_id}-S{i:05d}",doc.document_id,doc.source_type,i,c,pos,end,bool(tokens)))
    return out
