from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass
class ImportedDocument:
    document_id: str
    filename: str
    media_type: str
    source_type: str
    text: str
    sha256: str
    warnings: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    def to_dict(self): return asdict(self)

@dataclass
class Segment:
    segment_id: str
    document_id: str
    source_type: str
    ordinal: int
    text: str
    char_start: int
    char_end: int
    pseudonymized: bool = False
    def to_dict(self): return asdict(self)

@dataclass
class CodingSuggestion:
    segment_id: str
    candidates: list[dict[str, Any]]
    decision_status: str = "A_ARBITRER"
    human_validation_required: bool = True
    def to_dict(self): return asdict(self)
