from __future__ import annotations
import math
import numpy as np
from scipy.stats import chi2_contingency

def descriptive(values:list[float])->dict:
    a=np.asarray(values,dtype=float)
    if a.size==0: return {"n":0,"mean":None,"median":None,"std":None,"min":None,"max":None}
    return {"n":int(a.size),"mean":float(a.mean()),"median":float(np.median(a)),"std":float(a.std(ddof=1)) if a.size>1 else 0.0,"min":float(a.min()),"max":float(a.max())}

def chi_square(table:list[list[float]])->dict:
    a=np.asarray(table,dtype=float)
    if a.ndim!=2 or min(a.shape)<2 or np.any(a<0): raise ValueError("CONTINGENCY_TABLE_INVALID")
    chi2,p,dof,expected=chi2_contingency(a)
    n=a.sum(); k=min(a.shape)-1; v=math.sqrt(chi2/(n*k)) if n and k else 0.0
    return {"chi2":float(chi2),"p_value":float(p),"dof":int(dof),"cramers_v":float(v),"expected":expected.tolist(),"causal_interpretation_allowed":False}
