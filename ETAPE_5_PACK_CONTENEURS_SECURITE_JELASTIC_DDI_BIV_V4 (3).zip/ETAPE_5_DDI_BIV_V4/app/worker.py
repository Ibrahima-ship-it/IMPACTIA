"""Worker de préproduction.

Il refuse le traitement tant qu'aucun orchestrateur authentifié n'est configuré.
OCR, transcription et antivirus doivent écrire leurs résultats dans le journal d'audit.
"""
import os
import sys

if os.getenv("IMPACTIA_ENV") == "production":
    raise SystemExit("WORKER_PRODUCTION_NOT_HOMOLOGATED")

print("IMPACTIA worker ready in non-production blocked mode", flush=True)
sys.stdout.flush()
import time
while True:
    time.sleep(30)

