#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

fail() { printf 'FAIL:%s\n' "$1"; exit 1; }
command -v docker >/dev/null 2>&1 || fail DOCKER_ABSENT
docker compose version >/dev/null 2>&1 || fail COMPOSE_ABSENT

if [ "${GITHUB_ACTIONS:-false}" = "true" ]; then
  scripts/prepare_ci_environment.sh
fi

test -f .env || fail ENV_ABSENT

if grep -Eq 'CHANGE_|example\.invalid' .env; then
  fail PLACEHOLDERS_PRESENT
fi

set -a
. ./.env
set +a

python3 scripts/preflight.py
docker compose config --quiet
docker compose build --pull
docker compose up --detach --wait --wait-timeout 300

cleanup() { docker compose down --remove-orphans >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM

api_id=$(docker compose ps --quiet api)
test -n "$api_id" || fail API_CONTAINER_ABSENT
docker inspect --format '{{json .State.Health.Status}}' "$api_id" | grep -q healthy || fail API_UNHEALTHY

docker compose exec -T postgres psql --set=ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<'SQL'
DO $$
DECLARE a uuid := gen_random_uuid(); b uuid := gen_random_uuid();
BEGIN
  INSERT INTO organizations(id,name) VALUES(a,'Tenant A'),(b,'Tenant B');
  INSERT INTO projects(organization_id,name) VALUES(a,'Projet A'),(b,'Projet B');
END $$;
SQL

docker compose exec -T postgres sh -eu -c '
PGPASSWORD="$POSTGRES_APP_PASSWORD" psql --set=ON_ERROR_STOP=1 --username "$POSTGRES_APP_USER" --dbname "$POSTGRES_DB" <<SQL
BEGIN;
SELECT set_config('\''app.organization_id'\'', (SELECT id::text FROM organizations WHERE name='\''Tenant A'\''), true);
DO \$\$ BEGIN
  IF (SELECT count(*) FROM projects) <> 1 THEN RAISE EXCEPTION '\''RLS isolation failed'\''; END IF;
END \$\$;
ROLLBACK;
SQL
'

docker compose exec -T clamav sh -eu -c '
  printf %s WDVPIVAlQEFQWzRcUFpYNTQoUF4pN0NDKTd9JEVJQ0FSLVNUQU5EQVJELUFOVElWSVJVUy1URVNULUZJTEUhJEgrSCo= \
    | base64 -d > /tmp/eicar.com
  clamdscan /tmp/eicar.com
' 2>&1 | grep -Ei 'FOUND|Eicar' || fail ANTIVIRUS_EICAR_NOT_DETECTED
docker compose exec -T clamav rm -f /tmp/eicar.com

backup_file=$(mktemp)
docker compose exec -T postgres pg_dump --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" --format=custom > "$backup_file"
test -s "$backup_file" || fail BACKUP_EMPTY
sha256sum "$backup_file"
rm -f "$backup_file"

docker compose ps
printf 'VERDICT_ETAPE_5=20/20\n'
