from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
errors: list[str] = []

required = [
    "Dockerfile", "docker-compose.yml", ".env.example", "config/nginx/nginx.conf",
    "db/001_roles.sh", "db/002_schema.sql", "app/platform_api.py", "scripts/runtime_acceptance.sh",
    "scripts/prepare_ci_environment.sh", ".github/workflows/acceptance-step5.yml",
    "artifacts/ETAPE_3_REGISTRE_INFORMATIQUE_47_FICHES_DDI_BIV_V4.json",
]
for item in required:
    if not (ROOT / item).is_file(): errors.append(f"MISSING:{item}")

compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
for service in ("gateway", "api", "worker", "postgres", "redis", "minio", "clamav"):
    if not re.search(rf"^  {service}:$", compose, re.M): errors.append(f"SERVICE_MISSING:{service}")
if "privileged: true" in compose: errors.append("PRIVILEGED_CONTAINER")
published = re.findall(r'^\s+-\s+["\']([^"\']+:[0-9]+)["\']\s*$', compose, re.M)
for binding in published:
    if binding.count(":") >= 2 and not binding.startswith("127.0.0.1:"):
        errors.append(f"PUBLIC_PORT_REVIEW:{binding}")

env = (ROOT / ".env.example").read_text(encoding="utf-8")
for bad in ("SECRET_KEY_IMPACTIA_ENTERPRISE_2026", "password123", "changeme-now"):
    if bad.lower() in env.lower(): errors.append("HARDCODED_SECRET")

registry_path = ROOT / "artifacts/ETAPE_3_REGISTRE_INFORMATIQUE_47_FICHES_DDI_BIV_V4.json"
registry = json.loads(registry_path.read_text(encoding="utf-8"))
codes = [f["code"] for f in registry["fiches"]]
expected = [f"M{i:02d}" for i in range(1, 13)] + [f"L{i:02d}" for i in range(1, 36)]
if codes != expected: errors.append("FICHE_ORDER_OR_COUNT")
if registry["canonical_source"]["sha256"] != "0e65a00a359137c4e67fe927325c0bf14c3b48153cca3b0dc7279d90c4ceb346":
    errors.append("CANONICAL_SOURCE_HASH_CHANGED")

result = {
    "status": "PASS" if not errors else "FAIL",
    "errors": errors,
    "checks": {"files": len(required), "services": 7, "fiches": len(codes)},
    "registry_sha256": hashlib.sha256(registry_path.read_bytes()).hexdigest(),
    "docker_runtime_tested": False,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(0 if not errors else 1)
