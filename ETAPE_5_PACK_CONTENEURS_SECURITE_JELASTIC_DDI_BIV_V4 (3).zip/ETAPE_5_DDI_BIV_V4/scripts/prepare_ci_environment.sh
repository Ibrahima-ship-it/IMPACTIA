#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
command -v openssl >/dev/null 2>&1 || { printf 'FAIL:OPENSSL_ABSENT\n'; exit 1; }

random_hex() { openssl rand -hex 32; }
owner_password=$(random_hex)
app_password=$(random_hex)
api_key=$(random_hex)
s3_user="ci$(openssl rand -hex 8)"
s3_password=$(random_hex)

umask 077
{
  printf 'IMPACTIA_ENV=test\n'
  printf 'IMPACTIA_AUTH_MODE=test-key\n'
  printf 'IMPACTIA_API_KEY=%s\n' "$api_key"
  printf 'POSTGRES_DB=impactia\nPOSTGRES_USER=impactia_owner\n'
  printf 'POSTGRES_PASSWORD=%s\n' "$owner_password"
  printf 'POSTGRES_APP_USER=impactia_app\nPOSTGRES_APP_PASSWORD=%s\n' "$app_password"
  printf 'DATABASE_URL=postgresql+psycopg://impactia_app:%s@postgres:5432/impactia\n' "$app_password"
  printf 'REDIS_URL=redis://redis:6379/0\nCLAMAV_HOST=clamav\nCLAMAV_PORT=3310\n'
  printf 'S3_ENDPOINT=http://minio:9000\nS3_BUCKET=impactia-quarantine\n'
  printf 'S3_ACCESS_KEY=%s\nS3_SECRET_KEY=%s\n' "$s3_user" "$s3_password"
  printf 'ENCRYPTION_KEY_ID=ci-ephemeral\nALLOWED_ORIGIN=https://www.impactia-group.com\n'
  printf 'MAX_UPLOAD_BYTES=52428800\nRETENTION_DAYS=1\n'
} > .env

mkdir -p certs
openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days 1 \
  -subj '/CN=app.impactia-group.com' \
  -keyout certs/privkey.pem -out certs/fullchain.pem >/dev/null 2>&1
chmod 600 .env certs/privkey.pem
printf 'CI_ENVIRONMENT_READY\n'

